

## Carregando os pacotes
library(tidytuesdayR)
library(janitor)
library(tidyverse)
library(formattable)


# Get the Data

# Read in with tidytuesdayR package 
# Install from CRAN via: install.packages("tidytuesdayR")
# This loads the readme and all the datasets for the week of interest

# Either ISO-8601 date or year/week works!

# install.packages("tidytuesdayR")
tuesdata <- tidytuesdayR::tt_load('2022-04-12')

fuel_gdp <- tuesdata$fuel_gdp
fuel_access <- tuesdata$fuel_access
death_timeseries <- tuesdata$death_timeseries
death_source <- tuesdata$death_source
death_fuel <- tuesdata$death_fuel
indoor_pollution <- tuesdata$indoor_pollution



## Base fuel_gdp ---------------------------------------------------------------

summary(fuel_gdp)
names(fuel_gdp)[c(4, 5, 6)] <- c("Clean_fuels", "GDP_capita", "Population")

# verificando a quantidade de NA's para a base fuel_gdp 
nrow(fuel_gdp[is.na(fuel_gdp$Clean_fuels),])/nrow(fuel_gdp)
nrow(fuel_gdp[is.na(fuel_gdp$GDP_capita),])/nrow(fuel_gdp)
nrow(fuel_gdp[is.na(fuel_gdp$Population),])/nrow(fuel_gdp)

# a base n�o ser� utilizada por tem muitos dados faltantes 



## Base fuel_access ------------------------------------------------------------

summary(fuel_access)
names(fuel_access)[c(4)] <- c("Clean_fuels_perc")

# verificando a quantidade de NA's para a base fuel_access 
nrow(fuel_access[is.na(fuel_access$Clean_fuels_perc),])/nrow(fuel_access)


fuel_access %>% 
  group_by(Year) %>% 
  summarise(Percentual = mean(Clean_fuels_perc, na.rm = TRUE)) %>% 
  ggplot() +
  geom_point(aes(x = Year, y = Percentual)) +
  geom_line(aes(x = Year, y = Percentual)) +
  theme(axis.title = element_text(size = 9)) +
  labs(subtitle="Acesso a combust�veis limpos para cozinhar (% da popula��o) mundial", 
       y="Combust�vel limpos (%)", 
       x="Ano", 
       title="Acesso a combust�veis limpos", 
       caption = "Source: fuel_access") 





## Base death_timeseries -------------------------------------------------------

summary(death_timeseries)

# a base n�o ser� utilizada por falta de descri��o das variaveis semelhantes



## Base death_source -----------------------------------------------------------

summary(death_source)
names(death_source)[c(4)] <- c("Deaths")

# verificando a quantidade de NA's para a base fuel_access 
nrow(death_source[is.na(death_source$Deaths),])/nrow(death_source)


death_source %>% 
  group_by(Year) %>% 
  summarise(Morte = mean(Deaths, na.rm = TRUE)) %>% 
  ggplot() +
  geom_line(aes(x = Year, y = Morte)) +
  geom_point(aes(x = Year, y = Morte)) +
  theme(axis.title = element_text(size = 9)) +
  labs(subtitle="M�dia de mortes causada por Polui��o do ar no mundo por ano", 
       y="M�dia mortes", 
       x="Ano", 
       title="M�dia de mortes causada por polui��o do ar", 
       caption = "Source: death_source")


death_source %>% 
  group_by(Year) %>% 
  summarise(Morte = sum(Deaths, na.rm = TRUE)) %>% 
  ggplot() +
  geom_line(aes(x = Year, y = Morte)) +
  geom_point(aes(x = Year, y = Morte)) +
  theme(axis.title = element_text(size = 9)) +
  labs(subtitle="Quantidade de mortes causada por Polui��o do ar no mundo por ano", 
       y="Mortes", 
       x="Ano", 
       title="Quantidade de mortes causada por polui��o do ar", 
       caption = "Source: death_source")



## Base death_fuel -------------------------------------------------------------

summary(death_fuel)

# a base n�o ser� utilizada por falta de descri��o das variaveis semelhantes




## Base indoor_pollution -------------------------------------------------------

names(indoor_pollution)[c(4)] <- c("Deaths_perc")

summary(indoor_pollution)

ano_min <- min(indoor_pollution$Year)
ano_max <- max(indoor_pollution$Year)

indoor_pollution %>% 
  group_by(Year) %>% 
  summarise(Mortes_perc = mean(Deaths_perc, na.rm = TRUE)) %>% 
  ggplot() +
  geom_point(aes(x = Year, y = Mortes_perc)) +
  geom_line(aes(x = Year, y = Mortes_perc)) +
  theme(axis.title = element_text(size = 9)) +
  labs(subtitle="Percentual m�dio de mortes causada por Polui��o do ar no mundo", 
       y="Percentual m�dio de mortes", 
       x="Ano", 
       title="Mortes causada por polui��o do ar", 
       caption = "Source: indoor_pollution")



# Tabela

indoor_pollution |>
  dplyr::filter(Year == "1990") |>
  group_by(Year, Entity) |>
  summarise(Mortes_perc = mean(Deaths_perc, na.rm = TRUE, sort = TRUE)) |>
  mutate(Mortes_perc = round(Mortes_perc, 1)) |>
  slice(1:10) |>
  select(`Ano` = Year,`Pa�s` = Entity, `Percentual Mortes` = Mortes_perc) |>
  gt::gt(caption = "Dez pa�ses com maior percentual de mortes em 1990")



indoor_pollution |>
  dplyr::filter(Year == "2019") |>
  group_by(Year, Entity) |>
  summarise(Mortes_perc = mean(Deaths_perc, na.rm = TRUE, sort = TRUE)) |>
  mutate(Mortes_perc = round(Mortes_perc, 1)) |>
  slice(1:10) |>
  select(`Ano` = Year, `Pa�s` = Entity, `Percentual Mortes` = Mortes_perc) |>
  gt::gt(caption = "Dez pa�ses com maior percentual de mortes em 2019")



